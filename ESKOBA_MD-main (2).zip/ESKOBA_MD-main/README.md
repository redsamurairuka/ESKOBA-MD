<img src="https://capsule-render.vercel.app/api?type=waving&color=0:87CEEB,100:87CEEB&height=180&section=header&text=ESKOBA%20MD%20WHATSAPP%20BOT&fontSize=38&fontColor=ffffff&fontFamily=Roboto&animation=twinkling" width="100%"/>

---

> **CURRENT BOT VERSION ➜ `3.0.0 ⚡`**
---

```
DONT FORGET TO FORK 🍴 & STAR 🌟 REPO😇
```
---

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=810&height=100&lines=+THANKS FOR RUKA+ESKOBA-MD;MULTI+DEVICE+WHATSAPP+BOT;CREATED+BY+ESKOBA+INXIDE" alt="Typing SVG" /></a>
  </p>
  
--- 

<a><img src='https://i.ibb.co/Q39CnPKH/8293473eb7c99088.jpg'/></a>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

***




### 1. 𐃁FORK THIS REPOSITORY IN BOT𐃁

`FORK 🍴 AND STAR 🚀 IF YOU LIKE THIS BOT`

  <a href="https://github.com/RED-SAMURAY1/ESKOBA_MD/fork"><img title="ESKOBA-MD" src="https://img.shields.io/badge/FORK-ESKOBA%20MD-BOTh?color=indigo&style=for-the-badge&logo=stackshare"></a>

---


### 2. 𐃁GET SESSION ID𐃁 


> **1. ESKOBA PAIR CODE SESSION ID**

<a href='https://ali-md-web-qr-pair-z8r2.onrender.com' target="_blank">
  <img alt='Pairing Code' src='https://img.shields.io/badge/Get%20Pairing%20Code-orange?style=for-the-badge&logo=opencv&logoColor=black'/>
</a>
<br> 

> **2. THA PAIR CODE SESSION ID🚀**

<a href='https://session-site-ruka.onrender.com' target="_blank">
  <img alt='Pairing Code' src='https://img.shields.io/badge/Get%20Pairing%20Code-darkpink?style=for-the-badge&logo=opencv&logoColor=black'/>
</a>
<br> 



---

### <h2 align="">𐃁ESKOBA-MD DEPLOYMENT OPTIONS𐃁</h2>

---

### <h4 align="">1. HEROKU</h4>
<p style="text-align: center; font-size: 1.2em;">


<p align="">
<a href='https://dashboard.heroku.com/new?template=https%3A%2F%2Fgithub.com%2FRED-SAMURAY1%2FESKOBA_MD' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-heroku ‎ deploy-FF004D?style=for-the-badge&logo=heroku&logoColor=white'/< width=160 height=30/p></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


### <h4 align="">2. KOYEB</h4>
<p style="text-align: center; font-size: 1.2em;">

<p align="">
<a href='https://app.koyeb.com/services/deploy?type=git&repository=itx-alii-raza/ALI-MD&ports=3000&env[PREFIX]=.&env[SESSION_ID]=&env[ALWAYS_ONLINE]=false&env[MODE]=public&env[AUTO_STATUS_MSG]=Seen%20status%20by%20SUBZERO-MD&env[AUTO_STATUS_REPLY]=false&env[AUTO_STATUS_SEEN]=true&env[AUTO_TYPING]=false&env[ANTI_LINK]=true&env[AUTO_REACT]=false&env[READ_MESSAGE]=false' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-koyeb ‎ deploy-FF009D?style=for-the-badge&logo=koyeb&logoColor=white'/< width=150 height=28/p></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <h4 align="">3. RAILWAY</h4>
<p style="text-align: center; font-size: 1.2em;">

<p align="">
<a href='https://railway.app/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-railway deploy-FF8700?style=for-the-badge&logo=railway&logoColor=white'/< width=150 height=28/p></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <h4 align="">4. RENDER</h4>
<p style="text-align: center; font-size: 1.2em;">
  
<p align="">
<a href='https://dashboard.render.com/web/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Render deploy-black?style=for-the-badge&logo=render&logoColot=white'/< width=150 height=28/p></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <h4 align="">5. HUGGING FACE</h4>
<p style="text-align: center; font-size: 1.2em;">
  
<p align="">
<a href='https://app.netlify.com/' target="_blank"><img alt='Netlify' src='https://img.shields.io/badge/-Netlify Deploy-CC00FF?style=for-the-badge&logo=huggingface&logoColor=white'/< width=150 height=28/p></a> </a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<details>

### <h4 align="">6. REPLIT</h4>
<p style="text-align: center; font-size: 1.2em;">

<p align="">
<a href='https://replit.com/~' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Replit Deploy-1976D2?style=for-the-badge&logo=replit&logoColor=white'/< width=150 height=28/p></a> </a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


## 🪦 PROJECT OWNER 
The main owner of this project is dead, so make a sacrificial offering to contact the owner࿐➺

<p align="">
<a href='https://t.me/legionofdoom999?text=*ɴᴇᴇᴅ+ʜᴇʟᴘ!.+ɪ+ᴍᴇssᴀɢᴇᴅ+ʏᴏᴜ+ғʀᴏᴍ+ʀᴇᴘᴏ!!*' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/ Telegram-25D366?style=for-the-badge&logo=telegram&logoColor=white'/< width=150 height=28/p></a> </a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


## ⛩️ WHATSAPP CHANNEL 🪾
Join the WhatsApp channel to get updates of this WhatsApp bot where you will also get special tools and special skills.

[![WhatsApp Channel](https://img.shields.io/badge/JOIN-WHATSAAP%20CHANNEL-25D366?style=for-the-badge&logo=whatsapp)](https://whatsapp.com/channel/0029Vb0pFMeGOj9r28xCQJ0w)

## 🪀 WHATSAPP GROUP
Join the WhatsApp channel to get updates of this WhatsApp bot where you will also get special tools and special skills.

[![WhatsApp Group](https://img.shields.io/badge/JOIN-WHATSAAP%20GROUP-25D366?style=for-the-badge&logo=whatsapp)](https://whatsapp.com/channel/0029Vb0pFMeGOj9r28xCQJ0w)

 


***

## <h2 align="left">⚠️ REMINDER </h2>
<p style="text-align: center; font-size: 1.2em;">

- **DISCLAIMER:** MISUSING THE BOT MAY RESULT IN YOUR `WhatsApp` ACCOUNT BEING BANNED. NOTE THAT YOU CAN ONLY UNBAN YOUR ACCOUNT ONCE.
- I AM NOT RESPONSIBLE FOR ANY BANS OR MISUSE OF THE BOT. PLEASE KEEP THIS WARNING IN MIND BEFORE PROCEEDING.

---

<h2 align="left">ℹ️ NOTICE</h2>
<p style="text-align: center; font-size: 1.2em;">
  NOT FOR SALE - IF ANY PLUGIN'S CODE IS OBFUSCATED, YOU DO NOT HAVE PERMISSION TO EDIT IT IN ANY FORM.PLEASE REMEMBER TO GIVE CREDIT IF YOU ARE USING OR RE-UPLOADING MY PLUGINS/FILES. WISHING YOU A WONDERFUL DAY AHEAD!</p>
  
---

 <br>
<h2 align="center"> ⚠️ DISCLAIMER ⚠️
 </h2>
 
 ---

<h3 align="center"> DON'T COPY WITHOUT PERMISSION. Please get someone's permission
</h3>

<br>
---

```
THANK YOU DINESH , DINUWA , ALI MD OWNER🫂❤️‍🩹
```
-----
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

-----
  
<b><strong><summary align="" style="color: Yello;">EASIEST METHOD 2</summary></strong></b>
<p style="text-align: center; font-size: 1.2em;">

## <h3 align=""> 💐HOW TO DEPLOY ON HUGGING FACE🙂‍↕️</h3>
<h6 align-"center">
*❄️ Deploy ali-md On Hugging Face For Free !*

`Specs :`
- v2 CPU
- 16GB RAM

> `Steps to deploy`

`Step 1`
1. Go to hugginface.co/join and create an account and verify your email too.

`Step 2`
1. Go to https://huggingface.co/spaces/RED-SAMURAY1/ESKOBA_MD

2. Tap on *three dots* _(as shown in image)_

3. Tap on *duplicate space* _(as shown in image)_

`Step 3`
1. Fill your details, e.g., Session ID, Bot Name, owner number etc...

2. Tap on *duplicate space shown below*
